/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author smouche
 */
public class GasMileageCalculator {public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Ask the user for miles driven
        System.out.print("Enter the number of miles driven: ");
        double milesDriven = scanner.nextDouble();

        // Ask the user for gallons of gas used
        System.out.print("Enter the gallons of gas used: ");
        double gallonsUsed = scanner.nextDouble();

        // Calculate miles per gallon (MPG)
        if (gallonsUsed != 0) {
            double mpg = milesDriven / gallonsUsed;
            System.out.printf("Your miles per gallon (MPG) is: %.2f%n", mpg);
        } else {
            System.out.println("Gallons used cannot be zero.");
        }

        scanner.close();
    }
    
}
