/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author smouche
 */
public class EvenOrOddWithMod {public static void main(String[] args) {
        scanner scanner = new scanner(System.in);

        // Prompt the user
        System.out.print("Enter an integer: ");
        int number = scanner.nextInt();

        // Determine even or odd using %
        if (number % 2 == 0) {
            System.out.println(number + " is even.");
        } else {
            System.out.println(number + " is odd.");
        }

        scanner.close();
    }
}

    
